#!/bin/bash
echo "============================================"
echo "  VinSight - Setup Script (Mac/Linux)"
echo "============================================"

echo ""
echo "[1/4] Checking Python..."
python3 --version || { echo "ERROR: Python3 not found. Install from https://python.org"; exit 1; }

echo ""
echo "[2/4] Creating virtual environment..."
python3 -m venv venv

echo ""
echo "[3/4] Installing dependencies..."
source venv/bin/activate
pip install -r requirements.txt

echo ""
echo "[4/4] Setup complete!"
echo ""
echo "============================================"
echo "  To START the server:"
echo "  bash start.sh"
echo "  Then open: http://localhost:5000"
echo "============================================"
