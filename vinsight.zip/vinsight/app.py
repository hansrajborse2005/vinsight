"""
VinSight - Wine Quality & Health Predictor
Main Flask Application Entry Point
"""

from flask import Flask
from flask_cors import CORS
from backend.routes.auth_routes import auth_bp
from backend.routes.prediction_routes import prediction_bp
from backend.routes.user_routes import user_bp
from backend.models.database import init_db
import os

def create_app():
    app = Flask(
        __name__,
        template_folder='frontend/templates',
        static_folder='frontend/static'
    )

    # ── Config ──────────────────────────────────────
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'vinsight-secret-key-2025')
    app.config['DATABASE'] = os.path.join(os.path.dirname(__file__), 'database', 'vinsight.db')
    app.config['GROK_API_KEY'] = os.environ.get('GROK_API_KEY', '')

    # ── Extensions ──────────────────────────────────
    CORS(app)

    # ── Initialize Database ─────────────────────────
    init_db(app)

    # ── Register Blueprints ─────────────────────────
    app.register_blueprint(auth_bp,       url_prefix='/api/auth')
    app.register_blueprint(prediction_bp, url_prefix='/api/predict')
    app.register_blueprint(user_bp,       url_prefix='/api/user')

    # ── Serve Frontend ──────────────────────────────
    from flask import render_template
    @app.route('/')
    @app.route('/<path:path>')
    def index(path=''):
        return render_template('index.html')

    return app


if __name__ == '__main__':
    app = create_app()
    print("🍷 VinSight server starting at http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
