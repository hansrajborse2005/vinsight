# 🍷 VinSight — Wine Quality & Health Predictor

A full-stack web application for predicting wine quality and health impact
based on chemical composition, powered by **Python Flask + SQLite + Grok AI**.

---

## 📁 Project Structure

```
vinsight/
│
├── app.py                          ← Flask app factory (entry point)
├── run.py                          ← Local dev runner
├── requirements.txt                ← Python dependencies
├── .env                            ← Environment variables (API keys)
│
├── setup.bat / setup.sh            ← One-click setup (Windows / Mac-Linux)
├── start.bat / start.sh            ← One-click start (Windows / Mac-Linux)
│
├── backend/
│   ├── models/
│   │   ├── database.py             ← SQLite connection, schema, helpers
│   │   ├── user_model.py           ← User CRUD (register, login, get)
│   │   └── prediction_model.py     ← Prediction save, history, stats
│   │
│   ├── routes/
│   │   ├── auth_routes.py          ← /api/auth/* (register, login, logout, me)
│   │   ├── prediction_routes.py    ← /api/predict/* (analyze, history, stats)
│   │   └── user_routes.py          ← /api/user/* (profile, admin)
│   │
│   └── utils/
│       ├── auth_helper.py          ← Token generation, @login_required decorator
│       ├── wine_scorer.py          ← Rule-based quality scoring & health risk
│       └── grok_service.py         ← Grok (xAI) API integration
│
├── frontend/
│   ├── templates/
│   │   └── index.html              ← Main HTML template (served by Flask)
│   └── static/
│       ├── css/
│       │   └── style.css           ← All UI styles
│       └── js/
│           ├── api.js              ← API service layer (all fetch calls)
│           └── app.js              ← UI logic (auth, predict, history, profile)
│
└── database/
    └── vinsight.db                 ← SQLite database (auto-created on first run)
```

---

## 🗄️ Database Schema

### `users` table
| Column      | Type    | Description                    |
|-------------|---------|--------------------------------|
| id          | INTEGER | Primary key (auto)             |
| username    | TEXT    | Unique login name              |
| full_name   | TEXT    | Display name                   |
| email       | TEXT    | Optional email                 |
| password    | TEXT    | bcrypt hashed password         |
| role        | TEXT    | 'user' or 'admin'              |
| created_at  | TEXT    | Registration timestamp         |
| last_login  | TEXT    | Last login timestamp           |

### `predictions` table
| Column           | Type    | Description                    |
|------------------|---------|--------------------------------|
| id               | INTEGER | Primary key (auto)             |
| user_id          | INTEGER | Foreign key → users.id         |
| wine_type        | TEXT    | 'red' or 'white'               |
| alcohol          | REAL    | Alcohol %                      |
| sugar            | REAL    | Residual sugar g/L             |
| sulphites        | REAL    | SO₂ mg/L                       |
| volatile_acidity | REAL    | Volatile acidity               |
| citric_acid      | REAL    | Citric acid g/L                |
| ph               | REAL    | pH level                       |
| density          | REAL    | Density                        |
| chlorides        | REAL    | Chlorides g/L                  |
| quality_score    | INTEGER | 0–100 quality score            |
| health_level     | TEXT    | 'safe', 'moderate', 'harmful'  |
| ai_analysis      | TEXT    | Grok AI health explanation     |
| created_at       | TEXT    | Prediction timestamp           |

### `sessions` table
| Column     | Type    | Description                    |
|------------|---------|--------------------------------|
| id         | INTEGER | Primary key (auto)             |
| user_id    | INTEGER | Foreign key → users.id         |
| token      | TEXT    | Unique auth token (hex-64)     |
| expires_at | TEXT    | Token expiry (7 days)          |

---

## 🚀 How to Run (Local)

### Step 1 — Install Python
Download from https://www.python.org (version 3.9 or higher)

### Step 2 — Setup (run ONCE)

**Windows:**
```
Double-click  setup.bat
```

**Mac / Linux:**
```bash
bash setup.sh
```

### Step 3 — Add Grok API Key (optional)
Open `.env` file and replace:
```
GROK_API_KEY=xai-your-grok-api-key-here
```
with your actual key from https://console.x.ai

### Step 4 — Start Server

**Windows:**
```
Double-click  start.bat
```

**Mac / Linux:**
```bash
bash start.sh
```

### Step 5 — Open Browser
Go to: **http://localhost:5000**

---

## 🔑 API Endpoints

### Auth
| Method | Endpoint              | Description         | Auth Required |
|--------|-----------------------|---------------------|---------------|
| POST   | /api/auth/register    | Create account      | No            |
| POST   | /api/auth/login       | Login               | No            |
| POST   | /api/auth/logout      | Logout              | Yes           |
| GET    | /api/auth/me          | Get current user    | Yes           |

### Predictions
| Method | Endpoint              | Description         | Auth Required |
|--------|-----------------------|---------------------|---------------|
| POST   | /api/predict/analyze  | Run prediction      | Yes           |
| GET    | /api/predict/history  | Get history         | Yes           |
| GET    | /api/predict/stats    | Get stats           | Yes           |
| DELETE | /api/predict/{id}     | Delete prediction   | Yes           |

### User / Profile
| Method | Endpoint              | Description         | Auth Required |
|--------|-----------------------|---------------------|---------------|
| GET    | /api/user/profile     | Profile + stats     | Yes           |
| GET    | /api/user/all         | All users (admin)   | Admin         |

---

## 🧪 Wine Chemical Parameters

| Parameter        | Ideal Range      | Health Risk if High |
|------------------|------------------|---------------------|
| Alcohol (%)      | 10–13%           | Liver damage        |
| Residual Sugar   | < 5 g/L          | Diabetes risk       |
| Sulfites SO₂     | < 50 mg/L        | Allergy / asthma    |
| Volatile Acidity | < 0.4            | Vinegar / spoilage  |
| Citric Acid      | 0.2–0.6 g/L      | Tooth enamel erosion|
| pH               | 3.1–3.5          | Bacterial growth    |
| Chlorides        | < 0.05 g/L       | Blood pressure      |

---

## ⚙️ Tech Stack

| Layer     | Technology              |
|-----------|-------------------------|
| Backend   | Python 3 + Flask        |
| Database  | SQLite (file-based)     |
| Auth      | Token-based (sessions)  |
| Password  | bcrypt hashing          |
| AI        | Grok API (xAI)          |
| Frontend  | HTML + CSS + Vanilla JS |

---

Made with 🍷 by VinSight
