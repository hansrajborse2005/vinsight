# This folder stores the SQLite database file (vinsight.db)
# It is created automatically when you run the server for the first time.
# Do NOT delete this folder.
