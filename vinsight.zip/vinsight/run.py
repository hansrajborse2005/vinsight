"""
run.py — Local development runner
Usage: python run.py
"""
import os
from dotenv import load_dotenv

# Load .env file
load_dotenv()

from app import create_app

if __name__ == '__main__':
    app = create_app()
    print("\n" + "="*50)
    print("  🍷  VinSight Wine Quality Predictor")
    print("="*50)
    print("  ▶  Open browser: http://localhost:5000")
    print("  ⏹  Stop server:  Ctrl + C")
    print("="*50 + "\n")
    app.run(debug=True, host='0.0.0.0', port=5000)
