"""
backend/routes/auth_routes.py
Authentication Routes: /api/auth/*
"""

from flask import Blueprint, request, jsonify
from backend.models.user_model import UserModel
from backend.utils.auth_helper import create_session, delete_session, login_required

auth_bp = Blueprint('auth', __name__)


# ── POST /api/auth/register ──────────────────
@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.get_json()
    username  = data.get('username', '').strip().lower()
    full_name = data.get('full_name', '').strip()
    password  = data.get('password', '')
    email     = data.get('email', '').strip() or None

    # Validation
    if not username or not full_name or not password:
        return jsonify({'error': 'username, full_name and password are required'}), 400
    if len(password) < 6:
        return jsonify({'error': 'Password must be at least 6 characters'}), 400
    if len(username) < 3:
        return jsonify({'error': 'Username must be at least 3 characters'}), 400

    uid, err = UserModel.create(username, full_name, password, email)
    if err:
        return jsonify({'error': err}), 409

    token = create_session(uid)
    return jsonify({
        'message': 'Account created successfully',
        'token': token,
        'user': {'id': uid, 'username': username, 'full_name': full_name}
    }), 201


# ── POST /api/auth/login ─────────────────────
@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.get_json()
    username = data.get('username', '').strip().lower()
    password = data.get('password', '')

    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400

    user = UserModel.verify(username, password)
    if not user:
        return jsonify({'error': 'Invalid username or password'}), 401

    token = create_session(user['id'])
    return jsonify({
        'message': 'Login successful',
        'token': token,
        'user': {
            'id': user['id'],
            'username': user['username'],
            'full_name': user['full_name'],
            'role': user['role']
        }
    }), 200


# ── POST /api/auth/logout ────────────────────
@auth_bp.route('/logout', methods=['POST'])
@login_required
def logout():
    token = request.headers.get('Authorization', '').replace('Bearer ', '')
    delete_session(token)
    return jsonify({'message': 'Logged out successfully'}), 200


# ── GET /api/auth/me ─────────────────────────
@auth_bp.route('/me', methods=['GET'])
@login_required
def me():
    user = UserModel.get_by_id(request.user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({'user': user}), 200
