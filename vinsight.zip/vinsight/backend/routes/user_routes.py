"""
backend/routes/user_routes.py
User & Admin Routes: /api/user/*
"""

from flask import Blueprint, request, jsonify
from backend.models.user_model import UserModel
from backend.models.prediction_model import PredictionModel
from backend.utils.auth_helper import login_required

user_bp = Blueprint('user', __name__)


# ── GET /api/user/profile ────────────────────
@user_bp.route('/profile', methods=['GET'])
@login_required
def profile():
    user  = UserModel.get_by_id(request.user_id)
    stats = PredictionModel.stats_by_user(request.user_id)
    return jsonify({'user': user, 'stats': stats}), 200


# ── GET /api/user/all  (admin only) ──────────
@user_bp.route('/all', methods=['GET'])
@login_required
def all_users():
    me = UserModel.get_by_id(request.user_id)
    if me['role'] != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    return jsonify({'users': UserModel.get_all()}), 200


# ── GET /api/user/all-predictions  (admin) ───
@user_bp.route('/all-predictions', methods=['GET'])
@login_required
def all_predictions():
    me = UserModel.get_by_id(request.user_id)
    if me['role'] != 'admin':
        return jsonify({'error': 'Admin access required'}), 403
    return jsonify({'predictions': PredictionModel.get_all()}), 200
