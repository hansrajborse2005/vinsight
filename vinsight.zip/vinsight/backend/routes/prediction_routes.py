"""
backend/routes/prediction_routes.py
Prediction Routes: /api/predict/*
"""

from flask import Blueprint, request, jsonify
from backend.models.prediction_model import PredictionModel
from backend.utils.auth_helper import login_required
from backend.utils.wine_scorer import score_wine, health_risk, build_tags
from backend.utils.grok_service import get_grok_analysis

prediction_bp = Blueprint('prediction', __name__)

REQUIRED_FIELDS = ['wine_type','alcohol','sugar','sulphites','volatile_acidity',
                   'citric_acid','ph','density','chlorides']


# ── POST /api/predict/analyze ────────────────
@prediction_bp.route('/analyze', methods=['POST'])
@login_required
def analyze():
    data = request.get_json()

    # Validate required fields
    missing = [f for f in REQUIRED_FIELDS if f not in data]
    if missing:
        return jsonify({'error': f'Missing fields: {", ".join(missing)}'}), 400

    # Validate ranges
    v = {
        'wine_type':        data['wine_type'],
        'alcohol':          float(data['alcohol']),
        'sugar':            float(data['sugar']),
        'sulphites':        float(data['sulphites']),
        'volatile_acidity': float(data['volatile_acidity']),
        'citric_acid':      float(data['citric_acid']),
        'ph':               float(data['ph']),
        'density':          float(data['density']),
        'chlorides':        float(data['chlorides']),
    }

    # ── Core prediction logic ────────────────
    quality_score = score_wine(v)
    level         = health_risk(v)
    tags          = build_tags(v)
    ai_analysis   = get_grok_analysis(v, quality_score, level)

    # ── Save to DB ───────────────────────────
    v['quality_score'] = quality_score
    v['health_level']  = level
    v['ai_analysis']   = ai_analysis
    pid = PredictionModel.save(request.user_id, v)

    return jsonify({
        'prediction_id': pid,
        'quality_score': quality_score,
        'health_level':  level,
        'tags':          tags,
        'ai_analysis':   ai_analysis,
    }), 200


# ── GET /api/predict/history ─────────────────
@prediction_bp.route('/history', methods=['GET'])
@login_required
def history():
    limit = int(request.args.get('limit', 50))
    records = PredictionModel.get_by_user(request.user_id, limit)
    return jsonify({'history': records}), 200


# ── GET /api/predict/stats ───────────────────
@prediction_bp.route('/stats', methods=['GET'])
@login_required
def stats():
    s = PredictionModel.stats_by_user(request.user_id)
    return jsonify({'stats': s}), 200


# ── DELETE /api/predict/<id> ─────────────────
@prediction_bp.route('/<int:pred_id>', methods=['DELETE'])
@login_required
def delete_prediction(pred_id):
    PredictionModel.delete(pred_id, request.user_id)
    return jsonify({'message': 'Prediction deleted'}), 200
