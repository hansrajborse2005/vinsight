"""
backend/utils/grok_service.py
Grok (xAI) API Integration for Wine Health Analysis
"""

import requests
from flask import current_app
from backend.utils.wine_scorer import fallback_analysis


def get_grok_analysis(v: dict, score: int, level: str) -> str:
    """
    Call Grok API and return health analysis text.
    Falls back to rule-based text if API fails.
    """
    api_key = current_app.config.get('GROK_API_KEY', '')

    if not api_key:
        return fallback_analysis(v, level)

    prompt = f"""You are a wine quality and health expert. A user submitted this {v.get('wine_type','red')} wine:
- Alcohol: {v['alcohol']}%
- Residual Sugar: {v['sugar']} g/L
- Sulfites (SO₂): {v['sulphites']} mg/L
- Volatile Acidity: {v['volatile_acidity']}
- Citric Acid: {v['citric_acid']} g/L
- pH: {v['ph']}
- Density: {v['density']}
- Chlorides: {v['chlorides']} g/L
- Quality Score: {score}/100
- Health Risk Level: {level}

In exactly 3-4 sentences explain: (1) wine quality based on the chemistry, (2) how safe or harmful it is for health, (3) one specific health concern if any. Be practical and helpful. No bullet points."""

    try:
        resp = requests.post(
            'https://api.x.ai/v1/chat/completions',
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {api_key}'
            },
            json={
                'model': 'grok-3-fast',
                'max_tokens': 300,
                'messages': [
                    {'role': 'system', 'content': 'You are a concise wine quality and health expert.'},
                    {'role': 'user', 'content': prompt}
                ]
            },
            timeout=15
        )
        data = resp.json()
        return data['choices'][0]['message']['content'].strip()
    except Exception as e:
        print(f"⚠️  Grok API error: {e}")
        return fallback_analysis(v, level)
