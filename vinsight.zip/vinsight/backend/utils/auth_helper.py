"""
backend/utils/auth_helper.py
Token-based Authentication Helper
"""

import secrets
import hashlib
from datetime import datetime, timedelta
from functools import wraps
from flask import request, jsonify, current_app
from backend.models.database import query_db, execute_db


# ══════════════════════════════════════════════
#  TOKEN MANAGEMENT
# ══════════════════════════════════════════════

def generate_token():
    return secrets.token_hex(32)


def create_session(user_id):
    """Create a new session token valid for 7 days."""
    token = generate_token()
    expires = (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d %H:%M:%S')
    execute_db(
        "INSERT INTO sessions (user_id, token, expires_at) VALUES (?, ?, ?)",
        [user_id, token, expires]
    )
    return token


def validate_token(token):
    """Validate token and return user_id or None."""
    if not token:
        return None
    row = query_db(
        "SELECT user_id, expires_at FROM sessions WHERE token = ?",
        [token], one=True
    )
    if not row:
        return None
    # Check expiry
    expires = datetime.strptime(row['expires_at'], '%Y-%m-%d %H:%M:%S')
    if datetime.now() > expires:
        execute_db("DELETE FROM sessions WHERE token = ?", [token])
        return None
    return row['user_id']


def delete_session(token):
    execute_db("DELETE FROM sessions WHERE token = ?", [token])


# ══════════════════════════════════════════════
#  DECORATOR
# ══════════════════════════════════════════════

def login_required(f):
    """Route decorator — requires valid Bearer token."""
    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get('Authorization', '')
        token = auth_header.replace('Bearer ', '').strip()
        user_id = validate_token(token)
        if not user_id:
            return jsonify({'error': 'Unauthorized. Please login.'}), 401
        request.user_id = user_id
        return f(*args, **kwargs)
    return decorated
