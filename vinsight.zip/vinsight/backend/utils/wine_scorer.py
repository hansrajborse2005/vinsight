"""
backend/utils/wine_scorer.py
Rule-based Wine Quality Scoring & Health Risk Engine
"""


def score_wine(v: dict) -> int:
    """
    Calculate quality score (0–100) based on chemical parameters.
    Higher = better quality wine.
    """
    score = 60  # base

    # Alcohol: ideal 10–13%
    if 10 <= v['alcohol'] <= 13:
        score += 10
    elif v['alcohol'] > 14.5:
        score -= 10
    elif v['alcohol'] < 8.5:
        score -= 5

    # Residual Sugar: dry wine is generally higher quality
    if v['sugar'] < 5:
        score += 5
    elif v['sugar'] > 20:
        score -= 10
    elif v['sugar'] > 10:
        score -= 5

    # Sulfites (SO₂): moderate preservation
    if v['sulphites'] < 50:
        score += 8
    elif v['sulphites'] > 150:
        score -= 12
    elif v['sulphites'] > 100:
        score -= 5

    # Volatile Acidity: low = better (high = vinegar taste)
    if v['volatile_acidity'] < 0.4:
        score += 10
    elif v['volatile_acidity'] > 0.8:
        score -= 15
    elif v['volatile_acidity'] > 0.6:
        score -= 7

    # pH: ideal 3.1–3.5
    if 3.1 <= v['ph'] <= 3.5:
        score += 5
    elif v['ph'] > 3.8 or v['ph'] < 3.0:
        score -= 5

    # Citric Acid: freshness indicator
    if 0.2 <= v['citric_acid'] <= 0.6:
        score += 5
    elif v['citric_acid'] > 0.8:
        score -= 3

    # Chlorides: low is better
    if v['chlorides'] < 0.05:
        score += 5
    elif v['chlorides'] > 0.15:
        score -= 8

    # Density: normal range
    if 0.990 <= v['density'] <= 0.998:
        score += 2

    return max(10, min(100, score))


def health_risk(v: dict) -> str:
    """
    Calculate health risk level: 'safe' | 'moderate' | 'harmful'
    Based on WHO and nutritional guidelines.
    """
    risk = 0

    # High alcohol is the biggest health risk
    if v['alcohol'] > 14:
        risk += 35
    elif v['alcohol'] > 13:
        risk += 18
    elif v['alcohol'] > 12:
        risk += 8

    # Sulfites — allergen, asthma trigger
    if v['sulphites'] > 150:
        risk += 28
    elif v['sulphites'] > 100:
        risk += 14
    elif v['sulphites'] > 75:
        risk += 5

    # Volatile acidity — acetic acid (vinegar), toxic in high amounts
    if v['volatile_acidity'] > 0.8:
        risk += 22
    elif v['volatile_acidity'] > 0.5:
        risk += 10

    # High sugar → diabetes risk, calories
    if v['sugar'] > 30:
        risk += 15
    elif v['sugar'] > 15:
        risk += 8

    # High chlorides → blood pressure
    if v['chlorides'] > 0.15:
        risk += 10
    elif v['chlorides'] > 0.10:
        risk += 5

    if risk < 25:
        return 'safe'
    elif risk < 55:
        return 'moderate'
    else:
        return 'harmful'


def build_tags(v: dict) -> list:
    """Build human-readable health tags for each parameter."""
    tags = []

    # Alcohol
    if v['alcohol'] > 14:
        tags.append({'label': 'High Alcohol ⚠️', 'type': 'bad'})
    elif v['alcohol'] < 9:
        tags.append({'label': 'Low Alcohol', 'type': 'neutral'})
    else:
        tags.append({'label': 'Good Alcohol ✓', 'type': 'good'})

    # Sulfites
    if v['sulphites'] > 150:
        tags.append({'label': 'Excess SO₂ ⚠️', 'type': 'bad'})
    elif v['sulphites'] < 30:
        tags.append({'label': 'Very Low Sulfites ✓', 'type': 'good'})
    else:
        tags.append({'label': 'Normal SO₂', 'type': 'neutral'})

    # Volatile acidity
    if v['volatile_acidity'] > 0.7:
        tags.append({'label': 'High Volatile Acidity ⚠️', 'type': 'bad'})
    elif v['volatile_acidity'] < 0.3:
        tags.append({'label': 'Very Fresh ✓', 'type': 'good'})
    else:
        tags.append({'label': 'Acidity OK ✓', 'type': 'good'})

    # Sugar
    if v['sugar'] > 20:
        tags.append({'label': 'Very Sweet ⚠️', 'type': 'bad'})
    elif v['sugar'] > 10:
        tags.append({'label': 'Semi-Sweet', 'type': 'neutral'})
    else:
        tags.append({'label': 'Dry Wine ✓', 'type': 'good'})

    # pH
    if 3.1 <= v['ph'] <= 3.5:
        tags.append({'label': 'Ideal pH ✓', 'type': 'good'})
    elif v['ph'] > 3.8:
        tags.append({'label': 'High pH ⚠️', 'type': 'bad'})

    return tags


def fallback_analysis(v: dict, level: str) -> str:
    """Fallback analysis when Grok API is unavailable."""
    if level == 'safe':
        return (
            f"This {v.get('wine_type','red')} wine has a well-balanced chemical composition with "
            f"moderate alcohol ({v['alcohol']}%) and acceptable sulfite levels ({v['sulphites']} mg/L). "
            f"It is generally safe for moderate consumption and unlikely to cause adverse health effects "
            f"in healthy adults. The volatile acidity ({v['volatile_acidity']}) is within acceptable limits."
        )
    elif level == 'moderate':
        concern = f"elevated sulfites ({v['sulphites']} mg/L)" if v['sulphites'] > 100 else f"higher alcohol ({v['alcohol']}%)"
        return (
            f"This wine shows some concerning levels — notably {concern} — that warrant caution. "
            f"Consume in moderation and avoid if you are sensitive to sulfites or have liver concerns. "
            f"The overall composition is average but not ideal for daily consumption."
        )
    else:
        return (
            f"This wine has high health risk indicators: alcohol at {v['alcohol']}%, "
            f"sulfites at {v['sulphites']} mg/L, and volatile acidity of {v['volatile_acidity']} "
            f"— all above recommended thresholds. Regular consumption could strain the liver, "
            f"trigger allergic reactions from excess SO₂, and raise blood pressure. "
            f"It is strongly advised to avoid regular intake of this wine."
        )
