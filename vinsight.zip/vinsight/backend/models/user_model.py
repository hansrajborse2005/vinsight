"""
backend/models/user_model.py
User Model — CRUD operations
"""

import bcrypt
from backend.models.database import query_db, execute_db


class UserModel:

    @staticmethod
    def create(username, full_name, password, email=None):
        """Register a new user. Returns user_id or None if username exists."""
        existing = query_db("SELECT id FROM users WHERE username = ?", [username], one=True)
        if existing:
            return None, "Username already exists"

        hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        uid = execute_db(
            "INSERT INTO users (username, full_name, email, password) VALUES (?, ?, ?, ?)",
            [username, full_name, email, hashed]
        )
        return uid, None

    @staticmethod
    def verify(username, password):
        """Verify login credentials. Returns user row or None."""
        user = query_db("SELECT * FROM users WHERE username = ?", [username], one=True)
        if not user:
            return None
        if bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
            execute_db("UPDATE users SET last_login = datetime('now') WHERE id = ?", [user['id']])
            return dict(user)
        return None

    @staticmethod
    def get_by_id(user_id):
        row = query_db("SELECT id, username, full_name, email, role, created_at, last_login FROM users WHERE id = ?", [user_id], one=True)
        return dict(row) if row else None

    @staticmethod
    def get_all():
        rows = query_db("SELECT id, username, full_name, email, role, created_at, last_login FROM users")
        return [dict(r) for r in rows]
