"""
backend/models/prediction_model.py
Prediction Model — save & fetch wine predictions
"""

from backend.models.database import query_db, execute_db


class PredictionModel:

    @staticmethod
    def save(user_id, data):
        """Save a prediction to the database."""
        pid = execute_db("""
            INSERT INTO predictions
            (user_id, wine_type, alcohol, sugar, sulphites, volatile_acidity,
             citric_acid, ph, density, chlorides, quality_score, health_level, ai_analysis)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, [
            user_id,
            data['wine_type'],
            data['alcohol'],
            data['sugar'],
            data['sulphites'],
            data['volatile_acidity'],
            data['citric_acid'],
            data['ph'],
            data['density'],
            data['chlorides'],
            data['quality_score'],
            data['health_level'],
            data.get('ai_analysis', '')
        ])
        return pid

    @staticmethod
    def get_by_user(user_id, limit=50):
        """Get prediction history for a user."""
        rows = query_db("""
            SELECT * FROM predictions
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT ?
        """, [user_id, limit])
        return [dict(r) for r in rows]

    @staticmethod
    def get_all(limit=200):
        """Admin: get all predictions with usernames."""
        rows = query_db("""
            SELECT p.*, u.username, u.full_name
            FROM predictions p
            JOIN users u ON p.user_id = u.id
            ORDER BY p.created_at DESC
            LIMIT ?
        """, [limit])
        return [dict(r) for r in rows]

    @staticmethod
    def stats_by_user(user_id):
        """Get summary stats for a user."""
        row = query_db("""
            SELECT
                COUNT(*) as total,
                AVG(quality_score) as avg_score,
                SUM(CASE WHEN health_level='safe' THEN 1 ELSE 0 END) as safe_count,
                SUM(CASE WHEN health_level='moderate' THEN 1 ELSE 0 END) as moderate_count,
                SUM(CASE WHEN health_level='harmful' THEN 1 ELSE 0 END) as harmful_count
            FROM predictions WHERE user_id = ?
        """, [user_id], one=True)
        return dict(row) if row else {}

    @staticmethod
    def delete(prediction_id, user_id):
        """Delete a prediction (only owner can delete)."""
        execute_db("DELETE FROM predictions WHERE id = ? AND user_id = ?", [prediction_id, user_id])
