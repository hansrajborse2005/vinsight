"""
backend/models/database.py
SQLite Database — Schema & Initialization
"""

import sqlite3
import click
from flask import current_app, g


# ══════════════════════════════════════════════
#  CONNECTION HELPERS
# ══════════════════════════════════════════════

def get_db():
    """Get database connection for current request."""
    if 'db' not in g:
        g.db = sqlite3.connect(
            current_app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row  # dict-like rows
    return g.db


def close_db(e=None):
    """Close database connection after request."""
    db = g.pop('db', None)
    if db is not None:
        db.close()


# ══════════════════════════════════════════════
#  SCHEMA
# ══════════════════════════════════════════════

SCHEMA = """
-- Users table
CREATE TABLE IF NOT EXISTS users (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    username    TEXT    NOT NULL UNIQUE,
    full_name   TEXT    NOT NULL,
    email       TEXT    UNIQUE,
    password    TEXT    NOT NULL,       -- bcrypt hashed
    role        TEXT    DEFAULT 'user', -- 'user' | 'admin'
    created_at  TEXT    DEFAULT (datetime('now')),
    last_login  TEXT
);

-- Predictions table
CREATE TABLE IF NOT EXISTS predictions (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL,
    wine_type        TEXT    NOT NULL,   -- 'red' | 'white'
    alcohol          REAL    NOT NULL,
    sugar            REAL    NOT NULL,
    sulphites        REAL    NOT NULL,
    volatile_acidity REAL    NOT NULL,
    citric_acid      REAL    NOT NULL,
    ph               REAL    NOT NULL,
    density          REAL    NOT NULL,
    chlorides        REAL    NOT NULL,
    quality_score    INTEGER NOT NULL,   -- 0-100
    health_level     TEXT    NOT NULL,   -- 'safe' | 'moderate' | 'harmful'
    ai_analysis      TEXT,               -- Grok AI response
    created_at       TEXT    DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Sessions table (JWT alternative — simple token auth)
CREATE TABLE IF NOT EXISTS sessions (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    token      TEXT    NOT NULL UNIQUE,
    expires_at TEXT    NOT NULL,
    created_at TEXT    DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
"""


def init_db(app):
    """Initialize the database schema."""
    with app.app_context():
        db = sqlite3.connect(app.config['DATABASE'])
        db.executescript(SCHEMA)
        db.commit()
        db.close()
    app.teardown_appcontext(close_db)
    print("✅ Database initialized")


# ══════════════════════════════════════════════
#  QUERY HELPERS
# ══════════════════════════════════════════════

def query_db(query, args=(), one=False):
    """Run a SELECT query and return results."""
    cur = get_db().execute(query, args)
    rv = cur.fetchall()
    cur.close()
    return (rv[0] if rv else None) if one else rv


def execute_db(query, args=()):
    """Run an INSERT/UPDATE/DELETE query."""
    db = get_db()
    cur = db.execute(query, args)
    db.commit()
    return cur.lastrowid
