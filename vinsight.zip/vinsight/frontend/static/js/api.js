/**
 * frontend/static/js/api.js
 * All backend API calls in one place
 */

const API = {
  BASE: '/api',

  _token() { return localStorage.getItem('vinsight_token') || ''; },

  async _req(method, path, body = null) {
    const opts = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this._token()}`
      }
    };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(this.BASE + path, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  },

  // ── Auth ──────────────────────────────────
  async register(payload)  { return this._req('POST', '/auth/register', payload); },
  async login(payload)     { return this._req('POST', '/auth/login',    payload); },
  async logout()           { return this._req('POST', '/auth/logout'); },
  async me()               { return this._req('GET',  '/auth/me'); },

  // ── Predictions ───────────────────────────
  async analyze(payload)   { return this._req('POST', '/predict/analyze', payload); },
  async getHistory()       { return this._req('GET',  '/predict/history'); },
  async getStats()         { return this._req('GET',  '/predict/stats'); },
  async deletePrediction(id){ return this._req('DELETE', `/predict/${id}`); },

  // ── User / Profile ────────────────────────
  async getProfile()       { return this._req('GET',  '/user/profile'); },
};
