/**
 * frontend/static/js/app.js
 * VinSight UI Logic
 */

// ════════════════════════════════════════════
//  STATE
// ════════════════════════════════════════════
let currentUser = null;
let wineType    = 'red';

// ════════════════════════════════════════════
//  AUTH
// ════════════════════════════════════════════
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b, i) =>
    b.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'))
  );
  document.getElementById('login-form').style.display    = tab === 'login'    ? 'block' : 'none';
  document.getElementById('register-form').style.display = tab === 'register' ? 'block' : 'none';
  setAuthMsg('');
}

function setAuthMsg(msg, type = 'error') {
  const el = document.getElementById('auth-msg');
  el.textContent = msg;
  el.className   = 'auth-msg ' + type;
}

async function doLogin() {
  const btn  = document.getElementById('login-btn');
  const user = document.getElementById('l-user').value.trim();
  const pass = document.getElementById('l-pass').value;
  if (!user || !pass) return setAuthMsg('Please fill all fields.');

  btn.disabled = true;
  btn.innerHTML = '<div class="spinner"></div> Logging in...';
  try {
    const data = await API.login({ username: user, password: pass });
    localStorage.setItem('vinsight_token', data.token);
    currentUser = data.user;
    showApp();
  } catch (e) {
    setAuthMsg(e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Login';
  }
}

async function doRegister() {
  const btn   = document.getElementById('reg-btn');
  const name  = document.getElementById('r-name').value.trim();
  const user  = document.getElementById('r-user').value.trim();
  const email = document.getElementById('r-email').value.trim();
  const pass  = document.getElementById('r-pass').value;
  if (!name || !user || !pass) return setAuthMsg('Full name, username and password are required.');

  btn.disabled = true;
  btn.innerHTML = '<div class="spinner"></div> Creating...';
  try {
    const data = await API.register({ full_name: name, username: user, email, password: pass });
    localStorage.setItem('vinsight_token', data.token);
    currentUser = data.user;
    showApp();
  } catch (e) {
    setAuthMsg(e.message);
  } finally {
    btn.disabled = false;
    btn.textContent = 'Create Account';
  }
}

async function doLogout() {
  try { await API.logout(); } catch (e) {}
  localStorage.removeItem('vinsight_token');
  currentUser = null;
  document.getElementById('auth-screen').classList.add('active');
  document.getElementById('app-screen').classList.remove('active');
  document.getElementById('l-pass').value = '';
  setAuthMsg('');
}

function showApp() {
  document.getElementById('auth-screen').classList.remove('active');
  document.getElementById('app-screen').classList.add('active');
  document.getElementById('user-display').textContent = `👤 ${currentUser.full_name}`;
  showPage('predict');
}

// ════════════════════════════════════════════
//  NAVIGATION
// ════════════════════════════════════════════
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn:not(.logout-btn)').forEach(b => b.classList.remove('active'));
  document.getElementById('page-' + name).classList.add('active');
  const pages = ['predict', 'history', 'profile'];
  const btns  = document.querySelectorAll('.nav-btn:not(.logout-btn)');
  btns[pages.indexOf(name)]?.classList.add('active');
  if (name === 'history') loadHistory();
  if (name === 'profile') loadProfile();
}

// ════════════════════════════════════════════
//  SLIDERS
// ════════════════════════════════════════════
function updateVal(id, val) {
  document.getElementById(id).textContent = val;
}

function setWineType(type) {
  wineType = type;
  document.getElementById('btn-red').classList.toggle('active',   type === 'red');
  document.getElementById('btn-white').classList.toggle('active', type === 'white');
}

function getSliderValues() {
  return {
    wine_type:        wineType,
    alcohol:          parseFloat(document.getElementById('s-alcohol').value),
    sugar:            parseFloat(document.getElementById('s-sugar').value),
    sulphites:        parseFloat(document.getElementById('s-sulphites').value),
    volatile_acidity: parseFloat(document.getElementById('s-va').value),
    citric_acid:      parseFloat(document.getElementById('s-citric').value),
    ph:               parseFloat(document.getElementById('s-ph').value),
    density:          parseFloat(document.getElementById('s-density').value),
    chlorides:        parseFloat(document.getElementById('s-chlorides').value),
  };
}

// ════════════════════════════════════════════
//  PREDICTION
// ════════════════════════════════════════════
async function runPrediction() {
  const btn     = document.getElementById('predict-btn');
  const btnText = document.getElementById('btn-text');
  btn.disabled  = true;
  btnText.innerHTML = '<div class="spinner"></div> Analyzing...';

  try {
    const payload = getSliderValues();
    const data    = await API.analyze(payload);

    // Show result card
    const card = document.getElementById('result-card');
    card.style.display = 'block';
    card.className = 'result-card ' + data.health_level;

    const icons  = { safe: '🟢', moderate: '🟡', harmful: '🔴' };
    const titles = { safe: 'Good Quality Wine', moderate: 'Average Quality Wine', harmful: 'Poor Quality Wine' };
    const subs   = {
      safe:     'Low health risk — safe for moderate consumption',
      moderate: 'Moderate risk — consume with caution',
      harmful:  'High health risk — avoid regular consumption'
    };
    const barColors = { safe: '#4caf7d', moderate: '#f0a843', harmful: '#e05555' };

    document.getElementById('res-icon').textContent  = icons[data.health_level];
    document.getElementById('res-title').textContent = titles[data.health_level];
    document.getElementById('res-sub').textContent   = subs[data.health_level];
    document.getElementById('res-score').textContent = data.quality_score + '/100';

    const bar = document.getElementById('res-bar');
    bar.style.background = barColors[data.health_level];
    bar.style.width = '0%';
    setTimeout(() => { bar.style.width = data.quality_score + '%'; }, 60);

    // Tags
    document.getElementById('res-tags').innerHTML = data.tags
      .map(t => `<span class="htag ${t.type}">${t.label}</span>`)
      .join('');

    document.getElementById('ai-text').textContent = data.ai_analysis;

  } catch (e) {
    alert('Prediction failed: ' + e.message);
  } finally {
    btn.disabled = false;
    btnText.textContent = '🔬 Analyze Wine';
  }
}

// ════════════════════════════════════════════
//  HISTORY
// ════════════════════════════════════════════
async function loadHistory() {
  const con = document.getElementById('history-container');
  con.innerHTML = '<div class="loading-state">Loading history...</div>';
  try {
    const data = await API.getHistory();
    const h    = data.history;
    if (!h.length) {
      con.innerHTML = '<div class="hist-empty">🍷<br><br>No predictions yet.<br>Run your first analysis!</div>';
      return;
    }
    con.innerHTML = '<div class="hist-grid">' + h.map(e => `
      <div class="hist-card">
        <div class="hist-type">${e.wine_type === 'red' ? '🍷' : '🥂'}</div>
        <div class="hist-info">
          <h4>${e.wine_type === 'red' ? 'Red' : 'White'} Wine — Score: ${e.quality_score}/100</h4>
          <p>Alcohol: ${e.alcohol}% · SO₂: ${e.sulphites}mg/L · Sugar: ${e.sugar}g/L</p>
          <p class="hist-meta">${e.created_at}</p>
        </div>
        <div class="hist-badge ${e.health_level}">${e.health_level.charAt(0).toUpperCase() + e.health_level.slice(1)}</div>
      </div>
    `).join('') + '</div>';
  } catch (e) {
    con.innerHTML = `<div class="hist-empty">Error loading history: ${e.message}</div>`;
  }
}

// ════════════════════════════════════════════
//  PROFILE
// ════════════════════════════════════════════
async function loadProfile() {
  const con = document.getElementById('profile-container');
  con.innerHTML = '<div class="loading-state">Loading profile...</div>';
  try {
    const data  = await API.getProfile();
    const user  = data.user;
    const stats = data.stats;
    const avg   = stats.avg_score ? Math.round(stats.avg_score) : '—';

    con.innerHTML = `
      <div class="profile-grid" style="margin-bottom:1.5rem">
        <div class="stat-card">
          <span class="stat-num">${stats.total || 0}</span>
          <span class="stat-label">Total Predictions</span>
        </div>
        <div class="stat-card">
          <span class="stat-num">${avg}</span>
          <span class="stat-label">Avg Quality Score</span>
        </div>
        <div class="stat-card">
          <span class="stat-num" style="color:var(--safe)">${stats.safe_count || 0}</span>
          <span class="stat-label">Safe Wines</span>
        </div>
        <div class="stat-card">
          <span class="stat-num" style="color:var(--danger)">${stats.harmful_count || 0}</span>
          <span class="stat-label">Harmful Wines</span>
        </div>
      </div>

      <div class="profile-info">
        <h3>Account Details</h3>
        <div class="info-row"><span>Full Name</span><span>${user.full_name}</span></div>
        <div class="info-row"><span>Username</span><span>@${user.username}</span></div>
        <div class="info-row"><span>Email</span><span>${user.email || '—'}</span></div>
        <div class="info-row"><span>Role</span><span>${user.role}</span></div>
        <div class="info-row"><span>Member Since</span><span>${user.created_at?.split(' ')[0] || '—'}</span></div>
        <div class="info-row"><span>Last Login</span><span>${user.last_login?.split(' ')[0] || '—'}</span></div>
      </div>
    `;
  } catch (e) {
    con.innerHTML = `<div class="hist-empty">Error loading profile: ${e.message}</div>`;
  }
}

// ════════════════════════════════════════════
//  INIT — auto-login if token exists
// ════════════════════════════════════════════
window.onload = async () => {
  const token = localStorage.getItem('vinsight_token');
  if (token) {
    try {
      const data = await API.me();
      currentUser = data.user;
      showApp();
    } catch (e) {
      localStorage.removeItem('vinsight_token');
    }
  }
};
