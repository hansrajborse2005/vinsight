@echo off
echo ============================================
echo   VinSight - Setup Script (Windows)
echo ============================================

echo.
echo [1/4] Checking Python...
python --version
if errorlevel 1 (
    echo ERROR: Python not found. Install from https://python.org
    pause
    exit /b 1
)

echo.
echo [2/4] Creating virtual environment...
python -m venv venv

echo.
echo [3/4] Installing dependencies...
call venv\Scripts\activate
pip install -r requirements.txt

echo.
echo [4/4] Setup complete!
echo.
echo ============================================
echo   To START the server:
echo   1. Double-click  start.bat
echo   2. Open browser: http://localhost:5000
echo ============================================
pause
